package service;

import model.Show;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import repository.ShowRepository;

import java.util.List;

@Service
public class ShowService {

    @Autowired
    private ShowRepository showRepository;

    public Show salvar(Show show) {
        return showRepository.save(show);
    }

    public Show buscaPorIdShow(Long id) {
        return showRepository.findById(id).orElse(null);
    }

    public List<Show> buscaTodos() {
        return showRepository.findAll();
    }
}
