package controller;

import model.Show;
import service.ShowService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping(path = "appshow/show")
public class ShowController {

    @Autowired
    private ShowService showService;

    @PostMapping(consumes = MediaType.APPLICATION_JSON_VALUE,
            produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<Show> cadastrar(@RequestBody Show show) {
        Show novoShow = showService.salvar(show);
        return ResponseEntity.status(HttpStatus.CREATED).body(novoShow);
    }

    @GetMapping(value = "/{id}", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<Show> listarPorId(@PathVariable("id") Long id) {
        Show show = showService.buscaPorIdShow(id);
        if (show != null) {
            return ResponseEntity.status(HttpStatus.OK).body(show);
        } else {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).build();
        }
    }

    @GetMapping(produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<List<Show>> listarTodos() {
        List<Show> shows = showService.buscaTodos();
        return ResponseEntity.status(HttpStatus.OK).body(shows);
    }
}
