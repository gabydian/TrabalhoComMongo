package model;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;
import org.springframework.data.mongodb.core.mapping.Field;

@Document(collection = "appshow/show")
public class Show {
    @Id
    @Field("show_id")
    private int showId;
    private String location;
    private String date;
    @Field("available_tickets")
    private int availableTickets;

    public int getShowId() {
        return showId;
    }

    public void setShowId(int showId) {
        this.showId = showId;
    }

    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public int getAvailableTickets() {
        return availableTickets;
    }

    public void setAvailableTickets(int availableTickets) {
        this.availableTickets = availableTickets;
    }

    public int getAvailable_tickets() {
        return 0;
    }

    @Override
    public String toString() {
        return "Show{" +
                ", showId=" + showId +
                ", location='" + location + '\'' +
                ", date='" + date + '\'' +
                ", availableTickets=" + availableTickets +
                '}';
    }
}
